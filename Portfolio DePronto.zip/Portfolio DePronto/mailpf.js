function validate()
{
	var nn=document.f1.name.value;
	var em=document.f1.email.value;
	var sb=document.f1.subject.value;
	var msg=document.f1.message.value;
	

	if(nn=="")
		{
			document.f1.name.focus();
		}
		else
	if(em=="")
		{
			document.f1.email.focus();
		}
		else
	if(sb=="")
		{
			document.f1.subject.focus();
		}
		else
	if(msg=="")
		{
			document.f1.message.focus();
		}
		else
		{
			sendEmail();
		}

}


function sendEmail()
{
	
	var nn=document.f1.name.value;
	var em=document.f1.email.value;
	var sb=document.f1.subject.value;
	var msg=document.f1.message.value;

	
	Email.send({
			Host:"smtp.gmail.com",
			Username:"shauzab23@gmail.com",
			Password:"vqqdkcoltcwnqicv",
			To:em,
			From:"shauzab23@gmail.com",
			Subject:sb,
			Body:"Name: "+nn+"<br>Email: "+em+"<br>Message: "+msg,		
		}).then(message=>alert("Mail sent successfully"))
}